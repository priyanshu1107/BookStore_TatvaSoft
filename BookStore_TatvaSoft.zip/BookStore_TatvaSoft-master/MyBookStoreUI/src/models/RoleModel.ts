// ! is used for required parameters
export default class RoleModel {
  id!: number;
  name!: string;
}