// ! is used for required parameters
export default class BaseList<T> {
  results!: T;
  totalRecords!: number;
}