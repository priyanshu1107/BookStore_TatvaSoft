# BookStore_TatvaSoft
BookStore is a summer internship 2022 (TatvaSoft Company) project that is developed in a ReactJS, Dotnet and PostgreSQL technology
